def Rliehunxiao(messagelist):
    retlist=[[0 for i in range(4)] for i in range(4)]
    for i in range(4):
        def muti8(num):
            num*=8
            if num>=1024:
                num^=1132
            if num>=512:
                num^=566
            if num>=256:
                num^=283
            return num
        def muti4(num):
            num*=4
            if num>=512:
                num^=566
            if num>=256:
                num^=283
            return num
        def muti2(num):
            num*=2
            if num>=256:
                num^=283
            return num
        def muti9(num):
            return muti8(num)^num
        def muti11(num):
            return muti8(num)^muti2(num)^num
        def muti13(num):
            return muti8(num)^muti4(num)^num
        def muti14(num):
            return muti8(num)^muti4(num)^muti2(num)

        retlist[i][0]=muti14(messagelist[i][0])^muti11(messagelist[i][1])^muti13(messagelist[i][2])^muti9(messagelist[i][3])
        retlist[i][1]=muti9(messagelist[i][0])^muti14(messagelist[i][1])^muti11(messagelist[i][2])^muti13(messagelist[i][3])
        retlist[i][2]=muti13(messagelist[i][0])^muti9(messagelist[i][1])^muti14(messagelist[i][2])^muti11(messagelist[i][3])
        retlist[i][3]=muti11(messagelist[i][0])^muti13(messagelist[i][1])^muti9(messagelist[i][2])^muti14(messagelist[i][3])
    return retlist

# testlist=[[2,1,1,3],[3,2,1,1],[1,3,2,1],[1,1,3,2]]
# print(Rliehunxiao(testlist))