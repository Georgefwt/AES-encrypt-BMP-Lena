def openReverseSbox():
    f=open(r"SboxReverse.txt",'r')
    list=[[0 for i in range(16)] for i in range(16)]
    for i in range(0,16):
        for j in range(0,16):
            num=int(f.readline())
            list[i][j]=num
    return list
def zijiedaihuan(RSboxlist,message):
    line=int(message/16)
    colum=message%16
    return RSboxlist[colum][line]

def Rzijiedaihuan16(RSboxlist,message16):
    for i in range(4):
        for j in range(4):
            message16[i][j]=zijiedaihuan(RSboxlist,message16[i][j])
    return message16

