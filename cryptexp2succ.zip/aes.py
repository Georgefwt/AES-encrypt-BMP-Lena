from cv2 import cv2
from zijiedaihuan import openSbox
from zijiedaihuan import zijiedaihuan16
from hangyiwei import hangyiwei
from liehunxiao import liehunxiao
from lunmiyaojia import lunmiyaojia
from miyaokuozhan import lunmiyaobianhuan
import numpy as np

lunkey=[[121,43,34,15],[234,32,145,26],[137,189,170,24],[67,155,199,200]]
lunconst=[1,2,4,8,16,32,64,128,27,54]
Sboxlist=openSbox()
# cryptlie1=openlielist1()
# cryptlie2=openlielist2()
# cryptlie3=openlielist3()
# cryptlie4=openlielist4()
img=cv2.imread(r"input.bmp",0)
(height,width)=img.shape

#保证宽度为16的倍数
if (width%16)!=0:
    appendnum=16-width%16
    aplist=np.zeros((height,appendnum))
    img=np.append(img,aplist,axis=1)
    img=img.astype(np.int)
    width+=appendnum

lunkeylist=[lunkey]
for i in range(10):
    lunkey=lunmiyaobianhuan(lunkey,Sboxlist,lunconst[i])
    lunkeylist.append(lunkey)

countsize16=0
cursorj=0
templist=[[0 for i in range(4)] for i in range(4)]
for i in range(height):
    for j in range(width):
        templist[int(countsize16/4)][countsize16%4]=img[i][j]
        countsize16+=1
        if countsize16==16:
            templist=lunmiyaojia(templist,lunkeylist[0])#第一次轮密钥加
            for k in range(16):
                img[i][cursorj+k]=templist[int(k/4)][k%4]
            cursorj=j+1
            countsize16=0
    cursorj=0

for lunshu in range(10):
    #lunKey=lunmiyaobianhuan(lunkey,Sboxlist,lunconst[lunshu])
    for i in range(height):
        for j in range(width):
            templist[int(countsize16/4)][countsize16%4]=img[i][j]
            countsize16+=1
            if countsize16==16:
                templist=zijiedaihuan16(Sboxlist,templist)#每轮的具体操作
                templist=hangyiwei(templist)
                if lunshu!=9:
                    templist=liehunxiao(templist)
                templist=lunmiyaojia(templist,lunkeylist[lunshu+1])

                for k in range(16):
                    img[i][cursorj+k]=templist[int(k/4)][k%4]
                cursorj=j+1
                countsize16=0
        cursorj=0

cv2.imwrite(r"lennaresult.bmp",img)
