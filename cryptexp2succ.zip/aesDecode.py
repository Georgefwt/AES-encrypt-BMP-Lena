from cv2 import cv2
from Reversezijiedaihuan import openReverseSbox,Rzijiedaihuan16
from zijiedaihuan import openSbox
from Reversehangyiwei import Rhangyiwei
from Reverseliehunxiao import Rliehunxiao
from lunmiyaojia import lunmiyaojia
from miyaokuozhan import lunmiyaobianhuan

lunkey=[[121,43,34,15],[234,32,145,26],[137,189,170,24],[67,155,199,200]]
lunconst=[1,2,4,8,16,32,64,128,27,54]
Sboxlist=openSbox()
RSboxlist=openReverseSbox()
img=cv2.imread(r"lennaresult.bmp",0)
(height,width)=img.shape

#保证宽度为16的倍数
# if (width%16)!=0:
#     appendnum=16-width%16
#     aplist=np.zeros((height,appendnum))
#     img=np.append(img,aplist,axis=1)
#     img=img.astype(np.int)

lunkeylist=[lunkey]
for i in range(10):
    lunkey=lunmiyaobianhuan(lunkey,Sboxlist,lunconst[i])
    lunkeylist.append(lunkey)

countsize16=0
cursorj=0
templist=[[0 for i in range(4)] for i in range(4)]
for i in range(height):
    for j in range(width):
        templist[int(countsize16/4)][countsize16%4]=img[i][j]
        countsize16+=1
        if countsize16==16:
            templist=lunmiyaojia(templist,lunkeylist[10])
            for k in range(16):
                img[i][cursorj+k]=templist[int(k/4)][k%4]
            cursorj=j+1
            countsize16=0
    cursorj=0


for lunshu in range(10):
    for i in range(height):
        for j in range(width):
            templist[int(countsize16/4)][countsize16%4]=img[i][j]
            countsize16+=1
            if countsize16==16:
                templist=Rhangyiwei(templist)
                templist=Rzijiedaihuan16(RSboxlist,templist)
                templist=lunmiyaojia(templist,lunkeylist[9-lunshu])
                if lunshu!=9:
                    templist=Rliehunxiao(templist)

                for k in range(16):
                    img[i][cursorj+k]=templist[int(k/4)][k%4]
                cursorj=j+1
                countsize16=0
        cursorj=0

cv2.imwrite(r"lennaresultdecode.bmp",img)
