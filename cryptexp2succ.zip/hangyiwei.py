def hangyiwei(messagelist):
    templist=[[0 for i in range(4)]for i in range(4)]
    for i in range(4):
        templist[i][0]=messagelist[i][0]
        templist[i][1]=messagelist[(i+1)%4][1]
        templist[i][2]=messagelist[(i+2)%4][2]
        templist[i][3]=messagelist[(i+3)%4][3]
    return templist
