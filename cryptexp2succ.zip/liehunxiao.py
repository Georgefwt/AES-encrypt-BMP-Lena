# def openlielist1():
#     f=open(r"cryptlie1.txt",'r')
#     list=[[0 for i in range(4)] for i in range(256)]
#     for i in range(256):
#         for j in range(4):
#             num=int(f.readline())
#             list[i][j]=num
#     return list
# def openlielist2():
#     f=open(r"cryptlie2.txt",'r')
#     list=[[0 for i in range(4)] for i in range(256)]
#     for i in range(256):
#         for j in range(4):
#             num=int(f.readline())
#             list[i][j]=num
#     return list
# def openlielist3():
#     f=open(r"cryptlie3.txt",'r')
#     list=[[0 for i in range(4)] for i in range(256)]
#     for i in range(256):
#         for j in range(4):
#             num=int(f.readline())
#             list[i][j]=num
#     return list
# def openlielist4():
#     f=open(r"cryptlie4.txt",'r')
#     list=[[0 for i in range(4)] for i in range(256)]
#     for i in range(256):
#         for j in range(4):
#             num=int(f.readline())
#             list[i][j]=num
#     return list

def liehunxiao(messagelist):
    def muti2(num):
        num*=2
        if num>=256:
            return num^283
        return num
    def muti3(num):
        return muti2(num)^num
    retlist=[[0 for i in range(4)] for i in range(4)]
    for i in range(4):
        retlist[i][0]=muti2(messagelist[i][0])^muti3(messagelist[i][1])^messagelist[i][2]^messagelist[i][3]
        retlist[i][1]=messagelist[i][0]^muti2(messagelist[i][1])^muti3(messagelist[i][2])^messagelist[i][3]
        retlist[i][2]=messagelist[i][0]^messagelist[i][1]^muti2(messagelist[i][2])^muti3(messagelist[i][3])
        retlist[i][3]=muti3(messagelist[i][0])^messagelist[i][1]^messagelist[i][2]^muti2(messagelist[i][3])
    return retlist

# testlist=[[14,9,13,11],[11,14,9,13],[13,11,14,9],[9,13,11,14]]
# print(liehunxiao(testlist))