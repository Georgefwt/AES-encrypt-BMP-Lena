def lunmiyaojia(messagelist,key):
    for i in range(4):
        for j in range(4):
            messagelist[i][j]=messagelist[i][j]^key[i][j]
    return messagelist