from zijiedaihuan import zijiedaihuan
def lunmiyaobianhuan(previousKey,Sboxlist,lunconst):
    templist=[[0 for i in range(4)]for i in range(4)]
    for i in range(4):
        for j in range(4):
            templist[i][j]=previousKey[i][j]
    
    for i in range(4):
        templist[3][i]=zijiedaihuan(Sboxlist,previousKey[3][(i+1)%4])^lunconst

    for i in range(4):
        templist[0][i]=templist[3][i]^previousKey[0][i]
    
    for i in range(1,4):
        for j in range(4):
            templist[i][j]=previousKey[i][j]^templist[i-1][j]
    return templist