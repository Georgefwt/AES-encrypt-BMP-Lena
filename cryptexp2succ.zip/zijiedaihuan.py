def openSbox():
    f=open(r"Sbox.txt",'r')
    list=[[0 for i in range(16)] for i in range(16)]
    for i in range(0,16):
        for j in range(0,16):
            num=int(f.readline())
            list[i][j]=num
    return list
def zijiedaihuan(Sboxlist,message):
    line=int(message/16)
    colum=message-line*16
    return Sboxlist[colum][line]

def zijiedaihuan16(Sboxlist,message16):
    for i in range(4):
        for j in range(4):
            message16[i][j]=zijiedaihuan(Sboxlist,message16[i][j])
    return message16

